""" CanvasSync by Mathias Perslev """

from ._version import __version__
